<?php

namespace App\Http\Controllers\ERP\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Staff;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function login(Request $request){
       

            if(is_numeric($request->userName))
            $employeeData =['phone'=>$request->userName,'password'=>$request->password];
        else
           $employeeData=['email'=>$request->userName,'password'=>$request->password];
    
           $employeeInfo = Staff::where('email',$request->userName)
           ->orWhere('phone', strtolower(trim($request->userName)))
           ->where('status', '!=',0)
           ->first();
           if(!empty(($employeeInfo))){
             if($employeeInfo->status ==1){
                if(Hash::check($request->password,$employeeInfo->password)){
                    if(Auth::guard('staff')->attempt($employeeData)){

                        $token = $employeeInfo->createToken(uniqid())->accessToken;
	

		return response()->json([
			'status' => true,
			'token_type' => 'bearer',
			'token' => $token,
			'message' => 'Login successfully'
		]);
                       
                       }
                }else{
                    $responseData=[
                        'errMsgFlag'=>true,
                        'msgFlag'=>false,
                        'msg'=>null,
                        'errMsg'=>'UserName or Password is wrong. Please try again !'

                    ];
                   
                }

             }else{
                
                $responseData=[
                    'errMsgFlag'=>true,
                    'msgFlag'=>false,
                    'msg'=>null,
                    'errMsg'=>'Faild To Login'

                ];
                
             }
    
           }else{
         
            $responseData=[
                'errMsgFlag'=>true,
                'msgFlag'=>false,
                'msg'=>null,
                'errMsg'=>'Ussrname or Password Wrong . Please try again.',
            ];
           
           }
           return response()->json($responseData, 200);
       
      
    }
}
