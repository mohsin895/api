<?php

namespace App\Http\Controllers\ERP\HRM;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Designation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepartmentController extends Controller
{
   public function index(Request $request){
   
        $dataList = Department::with('designationInfo')->get();
      return response()->json($dataList);

   
   }

   public function dataInfoAddOrUpdate(Request $request){
    try{
        DB::beginTransaction();

         $dataInfo = Department::find($request->dataId);
         if(empty($dataInfo)){
            $dataInfo =new Department();
            $dataInfo->deparmentName = $request->departmentName;
            $dataInfo->save();
            if($dataInfo->save()){
                if ($request->has('designations') && is_array($request->designations)) {
                    foreach ($request->designations as $designation) {
                        $designationInfo = new Designation();
                        $designationInfo->department_id = $dataInfo->id;
                        $designationInfo->designation = $designation;
                        $designationInfo->save();
                    }
                }
                $responseData=[
                    'errMsgFlag'=>false,
                    'msgFlag'=>true,
                    'msg'=>'Data insert sucessfully.',
                    'errMsg'=>null,

                ];
            }else{

                $responseData=[
                    'errMsgFlag'=>true,
                    'msgFlag'=>false,
                    'msg'=>null,
                    'errMsg'=>'Data insert fail, Please Try again!',
                ];
            }
           

            DB::commit();
            return response()->json($responseData, 200);
         }else{
               $dataInfo = Department::find($request->dataId);
               $dataInfo->deparmentName = $request->departmentName;
               $dataInfo->save();
               if($dataInfo->save()){
                $designationList = Designation::where('department_id',$dataInfo->id)->get();
                 foreach($designationList as $data){
                    Designation::where('id',$data->id)->delete();
                 }
                   if ($request->has('designations') && is_array($request->designations)) {
                       foreach ($request->designations as $designation) {
                           $designationInfo = new Designation();
                           $designationInfo->department_id = $dataInfo->id;
                           $designationInfo->designation = $designation;
                           $designationInfo->save();
                       }
                   }
                   $responseData=[
                       'errMsgFlag'=>false,
                       'msgFlag'=>true,
                       'msg'=>'Data Update sucessfully.',
                       'errMsg'=>null,
   
                   ];
               }else{
   
                   $responseData=[
                       'errMsgFlag'=>true,
                       'msgFlag'=>false,
                       'msg'=>null,
                       'errMsg'=>'Data Update fail, Please Try again!',
                   ];
               }
              
   
               DB::commit();
               return response()->json($responseData, 200);
         }
     
         
           

      


    }catch(\Exception $err){
        $responseData =[
            'errMsgFlag'=>true,
            'msgFlag'=>false,
            'msg'=>null,
            'errMsg'=>'Something Went Wrong . Please try again.',
            'errorDetails' => [
        'message' => $err->getMessage(),
        'trace' => $err->getTraceAsString()
    ],


        ];
        
        return response()->json($responseData, 200);
    }
   }

   public function dataInfoDelete(Request $request){
    try{
        DB::beginTransaction();

        $dataInfo = Department::find($request->dataId);

        if(empty($dataInfo)){
            $responseData=[
                'errMsgFlag'=>true,
                'msgFlag'=>false,
                'msg'=>null,
                'errMsg'=>'Data not found!',
            ];
            return response()->json($responseData, 404);
        }

        $designationList = Designation::where('department_id', $dataInfo->id)->get();
        foreach($designationList as $designation){
            $designation->delete();
        }

        if($dataInfo->delete()){
            DB::commit();
            $responseData=[
                'errMsgFlag'=>false,
                'msgFlag'=>true,
                'msg'=>'Data deleted successfully.',
                'errMsg'=>null,
            ];
            return response()->json($responseData, 200);
        } else {
            DB::rollBack();
            $responseData=[
                'errMsgFlag'=>true,
                'msgFlag'=>false,
                'msg'=>null,
                'errMsg'=>'Data deletion failed. Please try again!',
            ];
            return response()->json($responseData, 500);
        }
    } catch(\Exception $err){
        DB::rollBack();
        $responseData = [
            'errMsgFlag'=>true,
            'msgFlag'=>false,
            'msg'=>null,
            'errMsg'=>'Something went wrong. Please try again.',
            'errorDetails' => [
                'message' => $err->getMessage(),
                'trace' => $err->getTraceAsString()
            ],
        ];
        return response()->json($responseData, 500);
    }
}

}
